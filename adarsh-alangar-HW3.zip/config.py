config_file = "bf.json"
raw_log_file = "raw_send_rec_log.txt"
port = 25678
max_listens = 5
frequency = 3
THROUGH = 0
COST = 1
DELIM = "END"